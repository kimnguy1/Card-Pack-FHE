"use client"

// SnowEffect stub: user requested removing the snow animation.
// Keep a no-op export so imports remain valid while the effect is disabled.
export function SnowEffect() {
  return null
}
